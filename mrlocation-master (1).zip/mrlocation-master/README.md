# Mr.location
<img src='mrlocation_v2.jpg' />

get target location by link
<br />
# prerequisites
<pre>
<code>
apt update <br />
apt install git php python3 openssh -y <br />
pip3 install pyTelegramBotAPI 
</code></pre>


# run
<pre><code>
git clone https://github.com/mr0sploit/mrlocation <br />
cd mrlocation <br />
python3 mrlocation.py
</code></pre>

